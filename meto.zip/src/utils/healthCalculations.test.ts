/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateBMI,
  getBMICategory,
  calculateWHtR,
  calculateBodyFat,
  calculateVisceralFatIndex,
  calculateBMR,
  detectPhenotype,
  analyzeHealth,
  cmToInches,
  inchesToCm,
  kgToLbs,
  lbsToKg,
} from './healthCalculations';

test('BMI calculation: computes correct BMI for 175cm and 70kg', () => {
  const bmi = calculateBMI(175, 70);
  assert.equal(bmi, 22.9);
});

test('BMI category: identifies normal vs overweight for standard WHO and Asian WHO cutoffs', () => {
  // 24.0 is normal under WHO, but overweight under Asian cutoffs (>= 23)
  const whoRes = getBMICategory(24.0, 'who');
  assert.equal(whoRes.category, 'normal');

  const asianRes = getBMICategory(24.0, 'asian');
  assert.equal(asianRes.category, 'overweight');
});

test('WHtR calculation: verifies Ashwell half-height rule (<0.50 healthy)', () => {
  // Height 180cm, Waist 85cm -> 85 / 180 = 0.47 (Healthy)
  const healthy = calculateWHtR(85, 180);
  assert.equal(healthy.whtr, 0.47);
  assert.equal(healthy.category, 'healthy');
  assert.equal(healthy.riskLevel, 'low');
  assert.equal(healthy.waistExcessCm, 0);

  // Height 170cm, Waist 102cm -> 102 / 170 = 0.60 (High Risk)
  const highRisk = calculateWHtR(102, 170);
  assert.equal(highRisk.whtr, 0.6);
  assert.equal(highRisk.category, 'high_risk');
  assert.equal(highRisk.waistExcessCm > 0, true);
});

test('Body Fat calculation: computes US Navy formula for male', () => {
  // Male: 175cm, 75kg, waist 84cm, neck 38cm, hip 95cm
  const bf = calculateBodyFat('male', 30, 175, 75, 84, 38, 95);
  assert.equal(bf.method, 'navy');
  assert.equal(bf.bodyFatPercentage > 10 && bf.bodyFatPercentage < 22, true);
});

test('Phenotype Detection: accurately catches Normal-Weight Obesity (Skinny-Fat)', () => {
  // Normal BMI (22.5), but elevated waist (WHtR = 0.52) and higher body fat (26% for male)
  const phenotype = detectPhenotype(22.5, 'normal', 26, 'obese', 0.52, 'male');
  assert.equal(phenotype.phenotype, 'normal_weight_obesity');
  assert.equal(phenotype.title.includes('Normal-Weight Obesity'), true);
});

test('Phenotype Detection: catches Athletic Paradox (Muscle mass causing high BMI without fat risk)', () => {
  // BMI 27.5 (Overweight on scale), but low body fat (12%) and tight waist (WHtR 0.44)
  const phenotype = detectPhenotype(27.5, 'overweight', 12, 'athletes', 0.44, 'male');
  assert.equal(phenotype.phenotype, 'athletic_paradox');
});

test('BMR & Calorie targets: calculates realistic daily calorie requirements', () => {
  const bmr = calculateBMR('male', 75, 175, 28);
  assert.equal(bmr > 1600 && bmr < 1850, true);

  const fullAnalysis = analyzeHealth({
    gender: 'male',
    age: 28,
    unitSystem: 'metric',
    heightCm: 175,
    weightKg: 75,
    waistCm: 82,
    neckCm: 38,
    hipCm: 95,
    activityLevel: 'moderate',
    standard: 'who',
  });

  assert.equal(fullAnalysis.tdee > fullAnalysis.bmr, true);
  assert.equal(fullAnalysis.calorieTargets.standardLoss < fullAnalysis.tdee, true);
  assert.equal(fullAnalysis.metabolicScore > 70, true);
});

test('Unit conversions: bidirectional cm/inches and kg/lbs', () => {
  assert.equal(Math.round(cmToInches(25.4)), 10);
  assert.equal(Math.round(inchesToCm(10)), 25);
  assert.equal(Math.round(kgToLbs(10)), 22);
  assert.equal(Math.round(lbsToKg(22.0462)), 10);
});
