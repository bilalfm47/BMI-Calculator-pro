/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserBodyInputs, HealthAnalysisResult } from '../utils/healthCalculations';

export type Language = 'en' | 'ur';

export interface SavedScanRecord {
  id: string;
  timestamp: string;
  label: string;
  inputs: UserBodyInputs;
  results: HealthAnalysisResult;
}
