/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Gauge, Flame, ShieldAlert, Heart, TrendingUp, CheckCircle2 } from 'lucide-react';
import { HealthAnalysisResult, UnitSystem, cmToInches, kgToLbs } from '../utils/healthCalculations';
import { Language } from '../types';
import { getTranslation } from '../utils/translations';

interface TriMetricHeroCardsProps {
  results: HealthAnalysisResult;
  unitSystem: UnitSystem;
  language: Language;
}

export const TriMetricHeroCards: React.FC<TriMetricHeroCardsProps> = ({
  results,
  unitSystem,
  language,
}) => {
  const t = getTranslation(language);
  const isUrdu = language === 'ur';
  const isImperial = unitSystem === 'imperial';

  // Format helper
  const displayWaistExcess = isImperial
    ? `${Math.round(cmToInches(results.waistExcessCm) * 10) / 10} in`
    : `${results.waistExcessCm} cm`;

  const displayTargetWaist = isImperial
    ? `${Math.round(cmToInches(results.targetWaistCm) * 10) / 10} in`
    : `${results.targetWaistCm} cm`;

  const displayFatMass = isImperial
    ? `${Math.round(kgToLbs(results.fatMassKg) * 10) / 10} lbs`
    : `${results.fatMassKg} kg`;

  const displayLeanMass = isImperial
    ? `${Math.round(kgToLbs(results.leanMassKg) * 10) / 10} lbs`
    : `${results.leanMassKg} kg`;

  // BMI status badge coloring
  const getBMIBadgeColor = () => {
    switch (results.bmiCategory) {
      case 'normal':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      case 'underweight':
      case 'severely_underweight':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      case 'overweight':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      default:
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
    }
  };

  // WHtR status badge coloring
  const getWHtRBadgeColor = () => {
    switch (results.whtrRiskLevel) {
      case 'low':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      case 'moderate':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'high':
      case 'critical':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
    }
  };

  // Body Fat badge coloring
  const getBFBadgeColor = () => {
    switch (results.bodyFatCategory) {
      case 'athletes':
      case 'fitness':
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40';
      case 'average':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      case 'essential_fat':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      default:
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
    }
  };

  // Normalized bar percentages
  // BMI: range 15 to 40
  const bmiPct = Math.min(100, Math.max(0, ((results.bmi - 15) / 25) * 100));
  // WHtR: range 0.35 to 0.70
  const whtrPct = Math.min(100, Math.max(0, ((results.whtr - 0.35) / 0.35) * 100));
  // Body Fat: range 5% to 45%
  const bfPct = Math.min(100, Math.max(0, ((results.bodyFatPercentage - 5) / 40) * 100));

  return (
    <div className="space-y-4">
      {/* 3 Core Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: BMI */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-28 h-28 bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs font-semibold">
                <Gauge className="w-4 h-4 text-blue-400" />
                <span>{t.bmiLabel}</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getBMIBadgeColor()}`}>
                {results.bmiCategoryLabel}
              </span>
            </div>

            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-4xl font-extrabold tracking-tight font-mono text-white">
                {results.bmi}
              </span>
              <span className="text-xs text-slate-400 font-medium">kg/m²</span>
            </div>

            {/* Scale Gauge */}
            <div className="mt-4">
              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden flex border border-slate-800">
                <div style={{ width: `${bmiPct}%` }} className="h-full bg-gradient-to-r from-blue-500 via-emerald-400 to-rose-500 transition-all duration-300" />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>18.5 (Min)</span>
                <span>{results.bmiHealthyRange.max} (Norm)</span>
                <span>30.0 (Obese)</span>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800/80 text-xs text-slate-400 flex items-center justify-between">
            <span>{isUrdu ? 'صحت مند رینج:' : 'Healthy Target Range:'}</span>
            <span className="font-mono font-semibold text-slate-200">
              {results.bmiHealthyRange.min} - {results.bmiHealthyRange.max}
            </span>
          </div>
        </div>

        {/* Card 2: Body Fat % */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs font-semibold">
                <Flame className="w-4 h-4 text-emerald-400" />
                <span>{t.bodyFatLabel}</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getBFBadgeColor()}`}>
                {results.bodyFatCategoryLabel}
              </span>
            </div>

            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-4xl font-extrabold tracking-tight font-mono text-emerald-400">
                {results.bodyFatPercentage}%
              </span>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                {results.bodyFatMethod === 'navy' ? 'US Navy Standard' : 'BMI Estimated'}
              </span>
            </div>

            {/* Scale Gauge */}
            <div className="mt-4">
              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden flex border border-slate-800">
                <div style={{ width: `${bfPct}%` }} className="h-full bg-gradient-to-r from-cyan-400 via-emerald-400 to-rose-500 transition-all duration-300" />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>Athletic</span>
                <span>Fitness</span>
                <span>Overfat</span>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800/80 text-xs text-slate-400 flex items-center justify-between">
            <span>{isUrdu ? 'مسل بمقابلہ چربی:' : 'Lean vs Fat Mass:'}</span>
            <span className="font-mono font-semibold text-slate-200">
              {displayLeanMass} / {displayFatMass}
            </span>
          </div>
        </div>

        {/* Card 3: Waist-to-Height Ratio (WHtR) - The Crown Jewel */}
        <div className="bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-emerald-500/50 rounded-3xl p-5 shadow-2xl relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-emerald-300 text-xs font-bold uppercase tracking-wider">
                <Heart className="w-4 h-4 text-emerald-400 animate-pulse" />
                <span>{t.whtrLabel}</span>
              </div>
              <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${getWHtRBadgeColor()}`}>
                {results.whtrRiskLevel.toUpperCase()} RISK
              </span>
            </div>

            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-4xl font-black tracking-tight font-mono text-white">
                {results.whtr}
              </span>
              <span className="text-xs text-emerald-400 font-semibold">
                {results.whtr <= 0.49 ? 'Safe (<0.50)' : 'Above Safe Limit'}
              </span>
            </div>

            {/* Scale Gauge */}
            <div className="mt-4">
              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden flex border border-slate-800 relative">
                {/* 0.50 marker line */}
                <div className="absolute top-0 bottom-0 left-[42.8%] w-0.5 bg-white z-10 shadow" title="0.50 Half-Height Boundary" />
                <div style={{ width: `${whtrPct}%` }} className="h-full bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-500 transition-all duration-300" />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>0.40</span>
                <span className="text-emerald-400 font-bold">0.50 (Limit)</span>
                <span>0.60+ (High)</span>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800/80 text-xs flex items-center justify-between">
            <span className="text-slate-400">
              {results.waistExcessCm > 0
                ? (isUrdu ? 'اضافی کمر گھٹائیں:' : 'Reduce Waist By:')
                : (isUrdu ? 'کمر کی حیثیت:' : 'Heart Safe Status:')}
            </span>
            <span className={`font-mono font-bold ${results.waistExcessCm > 0 ? 'text-amber-400' : 'text-emerald-400 flex items-center gap-1'}`}>
              {results.waistExcessCm > 0 ? (
                `-${displayWaistExcess}`
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isUrdu ? 'مکمل محفوظ' : 'Optimal'}</span>
                </>
              )}
            </span>
          </div>
        </div>
      </div>

      {/* Quick Summary Pill Bar: Metabolic Health Composite & Cardiovascular Multiplier */}
      <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-slate-300">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{isUrdu ? 'میٹابولک ہیلتھ اسکور:' : 'Metabolic Vitality Score:'}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-24 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                style={{ width: `${results.metabolicScore}%` }}
                className={`h-full ${
                  results.metabolicScore >= 80
                    ? 'bg-emerald-400'
                    : results.metabolicScore >= 60
                    ? 'bg-amber-400'
                    : 'bg-rose-500'
                }`}
              />
            </div>
            <span className="font-mono font-extrabold text-white">
              {results.metabolicScore}/100
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <ShieldAlert className={`w-4 h-4 ${results.cardiovascularRiskMultiplier > 1.2 ? 'text-rose-400' : 'text-emerald-400'}`} />
          <span className="text-slate-400">
            {isUrdu ? 'کارڈیووسکولر رسک فیکٹر:' : 'Relative Cardiac Risk Factor:'}
          </span>
          <span className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
            results.cardiovascularRiskMultiplier > 1.2
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
              : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
          }`}>
            {results.cardiovascularRiskMultiplier}x
          </span>
        </div>
      </div>
    </div>
  );
};
