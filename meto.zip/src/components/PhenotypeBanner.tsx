/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AlertTriangle, ShieldCheck, Dumbbell, Flame, HeartCrack } from 'lucide-react';
import { HealthAnalysisResult } from '../utils/healthCalculations';
import { Language } from '../types';

interface PhenotypeBannerProps {
  results: HealthAnalysisResult;
  language: Language;
}

export const PhenotypeBanner: React.FC<PhenotypeBannerProps> = ({ results, language }) => {
  const isUrdu = language === 'ur';

  const getTheme = () => {
    switch (results.phenotype) {
      case 'athletic_paradox':
        return {
          icon: Dumbbell,
          bg: 'bg-gradient-to-r from-cyan-950/70 via-slate-900 to-cyan-950/40 border-cyan-500/50 text-cyan-300',
          badgeBg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
          titleColor: 'text-cyan-200',
        };
      case 'normal_weight_obesity':
        return {
          icon: AlertTriangle,
          bg: 'bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/50 border-amber-500/60 text-amber-300',
          badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
          titleColor: 'text-amber-200',
        };
      case 'high_metabolic_risk':
        return {
          icon: HeartCrack,
          bg: 'bg-gradient-to-r from-rose-950/80 via-slate-900 to-rose-950/50 border-rose-500/60 text-rose-300',
          badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
          titleColor: 'text-rose-200',
        };
      case 'central_adiposity':
        return {
          icon: Flame,
          bg: 'bg-gradient-to-r from-orange-950/70 via-slate-900 to-orange-950/40 border-orange-500/50 text-orange-300',
          badgeBg: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
          titleColor: 'text-orange-200',
        };
      case 'underweight_depletion':
        return {
          icon: AlertTriangle,
          bg: 'bg-gradient-to-r from-blue-950/70 via-slate-900 to-blue-950/40 border-blue-500/50 text-blue-300',
          badgeBg: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
          titleColor: 'text-blue-200',
        };
      default:
        return {
          icon: ShieldCheck,
          bg: 'bg-gradient-to-r from-emerald-950/70 via-slate-900 to-emerald-950/40 border-emerald-500/50 text-emerald-300',
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
          titleColor: 'text-emerald-200',
        };
    }
  };

  const theme = getTheme();
  const Icon = theme.icon;

  return (
    <div className={`rounded-3xl border-2 p-5 shadow-xl ${theme.bg}`}>
      <div className="flex flex-col sm:flex-row sm:items-start gap-4">
        <div className="w-12 h-12 rounded-2xl bg-slate-900/90 border border-slate-700/60 flex items-center justify-center shrink-0 shadow-lg">
          <Icon className="w-6 h-6 stroke-[2.2]" />
        </div>

        <div className="flex-1 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full border ${theme.badgeBg}`}>
              {isUrdu ? 'ریئل ٹائم تشخیص' : 'Phenotype Diagnosis'}
            </span>
            <h3 className={`text-base font-extrabold tracking-tight ${theme.titleColor}`}>
              {results.phenotypeTitle}
            </h3>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {results.phenotypeDescription}
          </p>

          {/* Urdu / Roman Urdu localized medical insight */}
          <div className="pt-2 border-t border-slate-800/80">
            <p className="text-xs text-slate-300 font-medium italic">
              <span className="text-emerald-400 font-bold not-italic mr-1.5">
                {isUrdu ? 'طبی خلاصہ:' : 'Urdu Clinical Summary:'}
              </span>
              {results.phenotypeUrduSummary}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
