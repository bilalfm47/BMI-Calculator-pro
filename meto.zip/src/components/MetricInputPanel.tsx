/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { User, Activity, Ruler, HeartPulse, Info } from 'lucide-react';
import { UserBodyInputs, UnitSystem, cmToInches, inchesToCm, kgToLbs, lbsToKg } from '../utils/healthCalculations';
import { Language } from '../types';
import { getTranslation } from '../utils/translations';

interface MetricInputPanelProps {
  inputs: UserBodyInputs;
  onChange: (updated: Partial<UserBodyInputs>) => void;
  language: Language;
}

export const MetricInputPanel: React.FC<MetricInputPanelProps> = ({
  inputs,
  onChange,
  language,
}) => {
  const t = getTranslation(language);
  const isImperial = inputs.unitSystem === 'imperial';
  const isUrdu = language === 'ur';

  // Display values converted based on unit system
  const displayHeight = isImperial
    ? Math.round(cmToInches(inputs.heightCm) * 10) / 10
    : Math.round(inputs.heightCm * 10) / 10;

  const displayWeight = isImperial
    ? Math.round(kgToLbs(inputs.weightKg) * 10) / 10
    : Math.round(inputs.weightKg * 10) / 10;

  const displayWaist = isImperial
    ? Math.round(cmToInches(inputs.waistCm) * 10) / 10
    : Math.round(inputs.waistCm * 10) / 10;

  const displayNeck = isImperial
    ? Math.round(cmToInches(inputs.neckCm) * 10) / 10
    : Math.round(inputs.neckCm * 10) / 10;

  const displayHip = isImperial
    ? Math.round(cmToInches(inputs.hipCm) * 10) / 10
    : Math.round(inputs.hipCm * 10) / 10;

  const handleHeightChange = (val: number) => {
    const cm = isImperial ? inchesToCm(val) : val;
    onChange({ heightCm: Math.max(90, Math.min(230, Math.round(cm * 10) / 10)) });
  };

  const handleWeightChange = (val: number) => {
    const kg = isImperial ? lbsToKg(val) : val;
    onChange({ weightKg: Math.max(30, Math.min(250, Math.round(kg * 10) / 10)) });
  };

  const handleWaistChange = (val: number) => {
    const cm = isImperial ? inchesToCm(val) : val;
    onChange({ waistCm: Math.max(45, Math.min(180, Math.round(cm * 10) / 10)) });
  };

  const handleNeckChange = (val: number) => {
    const cm = isImperial ? inchesToCm(val) : val;
    onChange({ neckCm: Math.max(20, Math.min(70, Math.round(cm * 10) / 10)) });
  };

  const handleHipChange = (val: number) => {
    const cm = isImperial ? inchesToCm(val) : val;
    onChange({ hipCm: Math.max(45, Math.min(180, Math.round(cm * 10) / 10)) });
  };

  // Convert height into feet & inches display helper
  const feetVal = Math.floor(displayHeight / 12);
  const inchesVal = Math.round(displayHeight % 12);

  // Healthy waist threshold for current height
  const maxSafeWaistCm = Math.round(inputs.heightCm * 0.49 * 10) / 10;
  const maxSafeWaistDisplay = isImperial
    ? Math.round(cmToInches(maxSafeWaistCm) * 10) / 10
    : maxSafeWaistCm;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <User className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-white tracking-wide">
            {isUrdu ? 'آپ کے جسمانی پیمانے (Biometrics)' : 'Personal Body Biometrics'}
          </h2>
        </div>
        <span className="text-xs text-slate-400">
          {inputs.unitSystem.toUpperCase()}
        </span>
      </div>

      {/* Gender Selection & Age */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Gender Toggle */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            {t.gender}
          </label>
          <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => onChange({ gender: 'male' })}
              className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                inputs.gender === 'male'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.male}
            </button>
            <button
              type="button"
              onClick={() => onChange({ gender: 'female' })}
              className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                inputs.gender === 'female'
                  ? 'bg-rose-500 text-slate-950 shadow-md shadow-rose-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.female}
            </button>
          </div>
        </div>

        {/* Age Input */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-300" htmlFor="age-input">
              {t.age}
            </label>
            <span className="text-xs font-mono font-bold text-emerald-400">
              {inputs.age} {isUrdu ? 'سال' : 'yrs'}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <input
              id="age-input"
              type="range"
              min={12}
              max={95}
              value={inputs.age}
              onChange={(e) => onChange({ age: Number(e.target.value) })}
              className="w-full accent-emerald-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
            />
            <input
              type="number"
              min={12}
              max={95}
              value={inputs.age}
              onChange={(e) => onChange({ age: Number(e.target.value) })}
              className="w-16 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-center font-mono text-sm text-white focus:outline-none focus:border-emerald-500"
              aria-label="Age in years"
            />
          </div>
        </div>
      </div>

      {/* Height & Weight Dual Sliders */}
      <div className="space-y-4">
        {/* Height */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <Ruler className="w-3.5 h-3.5 text-cyan-400" />
              <label className="text-xs font-semibold text-slate-300" htmlFor="height-range">
                {t.height}
              </label>
            </div>
            <div className="flex items-center gap-2">
              {isImperial && (
                <span className="text-xs text-slate-400">
                  ({feetVal}&apos;{inchesVal}&quot;)
                </span>
              )}
              <span className="text-xs font-mono font-bold text-cyan-400">
                {displayHeight} {isImperial ? 'in' : 'cm'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <input
              id="height-range"
              type="range"
              min={isImperial ? 36 : 100}
              max={isImperial ? 90 : 225}
              step={0.5}
              value={displayHeight}
              onChange={(e) => handleHeightChange(Number(e.target.value))}
              className="w-full accent-cyan-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
            />
            <input
              type="number"
              min={isImperial ? 36 : 100}
              max={isImperial ? 90 : 225}
              step={0.5}
              value={displayHeight}
              onChange={(e) => handleHeightChange(Number(e.target.value))}
              className="w-20 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-center font-mono text-sm text-white focus:outline-none focus:border-cyan-500"
              aria-label="Height input"
            />
          </div>
        </div>

        {/* Weight */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-300" htmlFor="weight-range">
              {t.weight}
            </label>
            <span className="text-xs font-mono font-bold text-emerald-400">
              {displayWeight} {isImperial ? 'lbs' : 'kg'}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <input
              id="weight-range"
              type="range"
              min={isImperial ? 70 : 35}
              max={isImperial ? 450 : 200}
              step={0.5}
              value={displayWeight}
              onChange={(e) => handleWeightChange(Number(e.target.value))}
              className="w-full accent-emerald-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
            />
            <input
              type="number"
              min={isImperial ? 70 : 35}
              max={isImperial ? 450 : 200}
              step={0.5}
              value={displayWeight}
              onChange={(e) => handleWeightChange(Number(e.target.value))}
              className="w-20 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-center font-mono text-sm text-white focus:outline-none focus:border-emerald-500"
              aria-label="Weight input"
            />
          </div>
        </div>
      </div>

      {/* Waist Circumference - Highlighted as Crucial Metric */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border-2 border-emerald-500/40 relative shadow-inner">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-4 h-4 text-emerald-400 animate-pulse" />
            <label className="text-xs font-bold text-emerald-300 uppercase tracking-wider" htmlFor="waist-range">
              {t.waist} ({isUrdu ? 'پائت کا گھیر' : 'Visceral Anchor'})
            </label>
          </div>
          <span className="text-sm font-mono font-black text-emerald-400">
            {displayWaist} {isImperial ? 'in' : 'cm'}
          </span>
        </div>

        <div className="flex items-center gap-3 mb-2">
          <input
            id="waist-range"
            type="range"
            min={isImperial ? 20 : 50}
            max={isImperial ? 65 : 160}
            step={0.5}
            value={displayWaist}
            onChange={(e) => handleWaistChange(Number(e.target.value))}
            className="w-full accent-emerald-400 h-2.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <input
            type="number"
            min={isImperial ? 20 : 50}
            max={isImperial ? 65 : 160}
            step={0.5}
            value={displayWaist}
            onChange={(e) => handleWaistChange(Number(e.target.value))}
            className="w-20 bg-slate-900 border border-emerald-500/60 rounded-lg px-2 py-1 text-center font-mono text-sm text-white focus:outline-none focus:border-emerald-400"
            aria-label="Waist circumference"
          />
        </div>

        {/* Real-time Ashwell Half-Height safe guideline badge */}
        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800/80 text-slate-400">
          <div className="flex items-center gap-1">
            <Info className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>
              {isUrdu ? 'محفوظ ترین حد (قد کا 49%):' : 'Safe Heart Limit (49% Height):'}
            </span>
          </div>
          <span className="font-semibold text-slate-200 font-mono">
            ≤ {maxSafeWaistDisplay} {isImperial ? 'in' : 'cm'}
          </span>
        </div>
      </div>

      {/* Navy Method Secondary Metrics: Neck & Hip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-800/70">
        {/* Neck */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[11px] font-semibold text-slate-400" htmlFor="neck-range">
              {t.neck} ({isUrdu ? 'گردن' : 'US Navy'})
            </label>
            <span className="text-[11px] font-mono font-bold text-slate-300">
              {displayNeck} {isImperial ? 'in' : 'cm'}
            </span>
          </div>
          <input
            id="neck-range"
            type="range"
            min={isImperial ? 10 : 25}
            max={isImperial ? 25 : 60}
            step={0.5}
            value={displayNeck}
            onChange={(e) => handleNeckChange(Number(e.target.value))}
            className="w-full accent-slate-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>

        {/* Hip (crucial for females, also useful for gynoid vs android fat assessment) */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[11px] font-semibold text-slate-400" htmlFor="hip-range">
              {t.hip} ({inputs.gender === 'female' ? (isUrdu ? 'کولہا - لازمی' : 'Required for Females') : (isUrdu ? 'کولہا' : 'Hip')})
            </label>
            <span className="text-[11px] font-mono font-bold text-slate-300">
              {displayHip} {isImperial ? 'in' : 'cm'}
            </span>
          </div>
          <input
            id="hip-range"
            type="range"
            min={isImperial ? 25 : 60}
            max={isImperial ? 65 : 160}
            step={0.5}
            value={displayHip}
            onChange={(e) => handleHipChange(Number(e.target.value))}
            className="w-full accent-slate-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* Activity Level Selector */}
      <div>
        <div className="flex items-center gap-1.5 mb-2">
          <Activity className="w-3.5 h-3.5 text-amber-400" />
          <label className="text-xs font-semibold text-slate-300" htmlFor="activity-select">
            {t.activityLevel}
          </label>
        </div>
        <select
          id="activity-select"
          value={inputs.activityLevel}
          onChange={(e) => onChange({ activityLevel: e.target.value as any })}
          className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-xl px-3 py-2.5 focus:outline-none focus:border-emerald-500"
        >
          <option value="sedentary">
            {isUrdu ? 'سست / ڈیسک ورک (ورزش نہ کے برابر - 1.2x)' : 'Sedentary (Little or no exercise - Desk job)'}
          </option>
          <option value="light">
            {isUrdu ? 'ہلکی ورزش (ہفتے میں 1-3 دن - 1.375x)' : 'Lightly Active (Exercise 1-3 days/week)'}
          </option>
          <option value="moderate">
            {isUrdu ? 'معتدل ورزش (ہفتے میں 3-5 دن - 1.55x)' : 'Moderately Active (Exercise 3-5 days/week)'}
          </option>
          <option value="active">
            {isUrdu ? 'باقاعدہ سخت ورزش (ہفتے میں 6-7 دن - 1.725x)' : 'Very Active (Hard training 6-7 days/week)'}
          </option>
          <option value="very_active">
            {isUrdu ? 'انتہائی سخت اتھلیٹ ٹریننگ (روزانہ 2 بار - 1.9x)' : 'Extra Active (Physical labor or 2x daily training)'}
          </option>
        </select>
      </div>
    </div>
  );
};
