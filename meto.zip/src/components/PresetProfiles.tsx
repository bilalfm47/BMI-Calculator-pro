/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, ShieldCheck, Dumbbell, AlertTriangle, Flame } from 'lucide-react';
import { UserBodyInputs } from '../utils/healthCalculations';
import { Language } from '../types';

interface PresetProfilesProps {
  onSelectPreset: (preset: Partial<UserBodyInputs>) => void;
  language: Language;
}

export const PresetProfiles: React.FC<PresetProfilesProps> = ({ onSelectPreset, language }) => {
  const isUrdu = language === 'ur';

  const presets = [
    {
      id: 'skinny-fat',
      icon: AlertTriangle,
      badge: isUrdu ? 'پوشیدہ خطرہ' : 'Hidden Risk',
      color: 'border-amber-500/40 hover:border-amber-400 bg-amber-500/10 text-amber-300',
      title: isUrdu ? 'مثال 1: Skinny-Fat (پوشیدہ چربی)' : 'Case 1: "Skinny-Fat" (Normal Weight Obesity)',
      subtitle: isUrdu
        ? 'BMI 22.8 نارمل، مگر پائت کی چربی اور ویسٹ ریشو زیادہ'
        : 'BMI 22.8 (Normal), but high visceral waist & fat %',
      data: {
        gender: 'male' as const,
        age: 32,
        heightCm: 172,
        weightKg: 68,
        waistCm: 89,
        neckCm: 37,
        hipCm: 92,
        activityLevel: 'sedentary' as const,
      },
    },
    {
      id: 'athlete',
      icon: Dumbbell,
      badge: isUrdu ? 'جھوٹا موٹاپا' : 'Paradox Solved',
      color: 'border-cyan-500/40 hover:border-cyan-400 bg-cyan-500/10 text-cyan-300',
      title: isUrdu ? 'مثال 2: اتھلیٹ / باڈی بلڈر' : 'Case 2: Muscular Athlete (False Overweight)',
      subtitle: isUrdu
        ? 'BMI 28.1 (زیادہ وزن)، مگر باڈی فیٹ صرف 11% اور کمر پتلی'
        : 'BMI 28.1 (Overweight), but only 11% body fat & tight waist',
      data: {
        gender: 'male' as const,
        age: 26,
        heightCm: 180,
        weightKg: 91,
        waistCm: 79,
        neckCm: 43,
        hipCm: 98,
        activityLevel: 'active' as const,
      },
    },
    {
      id: 'optimal',
      icon: ShieldCheck,
      badge: isUrdu ? 'مثالی فٹنس' : 'Optimal Zone',
      color: 'border-emerald-500/40 hover:border-emerald-400 bg-emerald-500/10 text-emerald-300',
      title: isUrdu ? 'مثال 3: مکمل متوازن اور فٹ' : 'Case 3: Ideal Cardiovascular Baseline',
      subtitle: isUrdu
        ? 'BMI 22.1، ویسٹ ریشو 0.44 اور باڈی فیٹ بہترین زون میں'
        : 'BMI 22.1, WHtR 0.44 & lean healthy body composition',
      data: {
        gender: 'female' as const,
        age: 27,
        heightCm: 168,
        weightKg: 59,
        waistCm: 69,
        neckCm: 33,
        hipCm: 93,
        activityLevel: 'moderate' as const,
      },
    },
    {
      id: 'metabolic-risk',
      icon: Flame,
      badge: isUrdu ? 'ہائی رسک' : 'High Visceral Risk',
      color: 'border-rose-500/40 hover:border-rose-400 bg-rose-500/10 text-rose-300',
      title: isUrdu ? 'مثال 4: وسرل فیٹ اور شوگر کا خطرہ' : 'Case 4: Central Adiposity & Metabolic Risk',
      subtitle: isUrdu
        ? 'کمر 104 سینٹی میٹر (قد کے نصف سے بہت زیادہ)، فوری توجہ درکار'
        : 'Waist 104 cm (WHtR 0.61), substantial cardiometabolic load',
      data: {
        gender: 'male' as const,
        age: 45,
        heightCm: 170,
        weightKg: 89,
        waistCm: 104,
        neckCm: 41,
        hipCm: 106,
        activityLevel: 'sedentary' as const,
      },
    },
  ];

  return (
    <div className="bg-slate-900/60 rounded-2xl p-4 border border-slate-800 shadow-md">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-4 h-4 text-emerald-400" />
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
          {isUrdu ? 'حقیقی کیسز ٹیسٹ کریں (کوئی اور ایپ یہ فرق نہیں دکھاتی)' : 'Explore Real Case Presets (Tests Features Unique To This App)'}
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
        {presets.map((preset) => {
          const Icon = preset.icon;
          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => onSelectPreset(preset.data)}
              className={`p-3 rounded-xl border text-left transition-all hover:scale-[1.01] active:scale-[0.99] flex flex-col justify-between ${preset.color}`}
            >
              <div className="flex items-center justify-between gap-1 mb-1.5">
                <div className="flex items-center gap-1.5 font-semibold text-xs text-white">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{preset.title}</span>
                </div>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-900/80 border border-slate-700/60 shrink-0">
                  {preset.badge}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                {preset.subtitle}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
