/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Target, Dumbbell, Apple, Moon, CheckCircle2 } from 'lucide-react';
import { HealthAnalysisResult } from '../utils/healthCalculations';
import { Language } from '../types';

interface ClinicalActionPlanProps {
  results: HealthAnalysisResult;
  language: Language;
}

export const ClinicalActionPlan: React.FC<ClinicalActionPlanProps> = ({ results, language }) => {
  const isUrdu = language === 'ur';

  // Strategy tailoring
  const isSkinnyFat = results.phenotype === 'normal_weight_obesity';
  const isAthlete = results.phenotype === 'athletic_paradox';
  const isHighRisk = results.phenotype === 'high_metabolic_risk' || results.phenotype === 'central_adiposity';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <Target className="w-5 h-5 text-emerald-400" />
        <div>
          <h3 className="text-base font-bold text-white tracking-wide">
            {isUrdu ? 'پرسنلائزڈ کلینیکل ایکشن پلان' : 'Personalized Clinical Protocol'}
          </h3>
          <p className="text-xs text-slate-400">
            {isUrdu
              ? 'آپ کی مخصوص باڈی کمپوزیشن اور وسرل فیٹ کے مطابق روزمرہ تجاویز'
              : 'Targeted interventions scientifically proven to reduce abdominal visceral fat and preserve lean tissue.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Step 1: Training */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 space-y-2">
          <div className="flex items-center gap-2 text-cyan-400">
            <Dumbbell className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">
              {isUrdu ? '1. ورزش کا طریقہ کار' : '1. Exercise Protocol'}
            </h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {isSkinnyFat
              ? (isUrdu
                  ? 'زیادہ کارڈیو کے بجائے ہفتے میں 3 سے 4 دن وزن اٹھانے والی ورزش (Resistance Training) کریں۔ اس سے مسل بنے گا اور پائت کی چربی تیزی سے گھلے گی۔'
                  : 'Prioritize heavy compound resistance training (3-4x/week) over excessive steady-state cardio to stimulate muscle protein synthesis and GLUT4 insulin sensitivity.')
              : isAthlete
              ? (isUrdu
                  ? 'آپ کا مسل ماس بہترین ہے۔ موجودہ روٹین جاری رکھیں اور جوڑوں کی حفاظت کیلئے متوازن کارڈیو شامل رکھیں۔'
                  : 'Maintain current progressive overload regime. Keep zone-2 aerobic base training to ensure vascular recovery.')
              : (isUrdu
                  ? 'ہفتے میں 150 منٹ تیز چہل قدمی (Brisk Walk) اور 2 دن ہلکی باڈی ویٹ ورزش شروع کریں۔'
                  : 'Start with 150 min/week Zone-2 brisk walking combined with 2 days full-body resistance training.')}
          </p>
        </div>

        {/* Step 2: Nutrition */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400">
            <Apple className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">
              {isUrdu ? '2. غذائی حکمت عملی' : '2. Nutrition & Visceral Diet'}
            </h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {isUrdu
              ? 'چینی، میٹھے مشروبات اور سفید میدہ مکمل ترک کریں۔ روزانہ ہر کھانے میں پروٹین (انڈے، چکن، دالیں) اور سلاد کو ترجیح دیں تاکہ جگر کی چربی پگھل سکے۔'
              : 'Eliminate liquid sugars and ultra-processed seed oils that rapidly elevate hepatic de novo lipogenesis. Anchor each meal with 30-40g quality protein and viscous soluble fiber.'}
          </p>
        </div>

        {/* Step 3: Sleep & Stress */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 space-y-2">
          <div className="flex items-center gap-2 text-amber-400">
            <Moon className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">
              {isUrdu ? '3. نیند اور کورٹیسول کنٹرول' : '3. Cortisol & Sleep Optimization'}
            </h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {isUrdu
              ? 'نیند کی کمی سے کورٹیسول ہارمون بڑھتا ہے جو سیدھا پائت کے اندرونی حصوں میں چربی جمع کرتا ہے۔ روزانہ 7 سے 8 گھنٹے پرسکون نیند لیں۔'
              : 'Chronic elevated cortisol stimulates visceral glucocorticoid receptors, driving abdominal adipose accumulation. Ensure 7-8 hours deep restorative sleep.'}
          </p>
        </div>
      </div>
    </div>
  );
};
