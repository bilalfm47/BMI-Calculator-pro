/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PieChart, ShieldAlert, Zap, Utensils, Award, FileText } from 'lucide-react';
import { HealthAnalysisResult, UnitSystem, cmToInches, kgToLbs } from '../utils/healthCalculations';
import { Language } from '../types';

interface MetabolicDeepDiveProps {
  results: HealthAnalysisResult;
  unitSystem: UnitSystem;
  language: Language;
}

export const MetabolicDeepDive: React.FC<MetabolicDeepDiveProps> = ({
  results,
  unitSystem,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<'composition' | 'cardio' | 'nutrition'>('composition');
  const isUrdu = language === 'ur';
  const isImperial = unitSystem === 'imperial';

  const displayLean = isImperial
    ? `${Math.round(kgToLbs(results.leanMassKg) * 10) / 10} lbs`
    : `${results.leanMassKg} kg`;

  const displayFat = isImperial
    ? `${Math.round(kgToLbs(results.fatMassKg) * 10) / 10} lbs`
    : `${results.fatMassKg} kg`;

  // Water weight estimate (~60% of lean mass)
  const waterKg = Math.round(results.leanMassKg * 0.62 * 10) / 10;
  const displayWater = isImperial
    ? `${Math.round(kgToLbs(waterKg) * 10) / 10} lbs`
    : `${waterKg} kg`;

  // Macro grams recommendation for body recomposition:
  // Protein: 2.0g per kg of lean mass
  const proteinGrams = Math.round(results.leanMassKg * 2.0);
  const proteinCalories = proteinGrams * 4;
  // Fat: 25% of maintenance calories
  const fatCalories = results.tdee * 0.25;
  const fatGrams = Math.round(fatCalories / 9);
  // Carbs: Remaining calories
  const carbCalories = Math.max(0, results.tdee - proteinCalories - fatCalories);
  const carbGrams = Math.round(carbCalories / 4);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-5">
      {/* Tab Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold text-white tracking-wide">
            {isUrdu ? 'مکمل میٹابولک تجزیہ (Deep Medical Insights)' : 'Advanced Metabolic & Clinical Breakdown'}
          </h3>
        </div>

        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('composition')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'composition'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isUrdu ? 'باڈی کمپوزیشن' : 'Body Composition'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('cardio')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'cardio'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isUrdu ? 'کارڈیو اور وسرل رسک' : 'Cardio & Visceral Risk'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('nutrition')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'nutrition'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isUrdu ? 'کیلوریز اور میکروز' : 'Caloric & Macro Engine'}
          </button>
        </div>
      </div>

      {/* Tab 1: Body Composition */}
      {activeTab === 'composition' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                {isUrdu ? 'لین باڈی ماس (مسل/ہڈیاں)' : 'Lean Body Mass (Active Tissue)'}
              </span>
              <span className="text-2xl font-black font-mono text-cyan-400 block">
                {displayLean}
              </span>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {100 - results.bodyFatPercentage}% of total body weight
              </span>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                {isUrdu ? 'مجموعی چربی کا وزن' : 'Total Adipose Fat Mass'}
              </span>
              <span className="text-2xl font-black font-mono text-rose-400 block">
                {displayFat}
              </span>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {results.bodyFatPercentage}% body fat percentage
              </span>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                {isUrdu ? 'پانی کی متوقع مقدار' : 'Estimated Total Body Water'}
              </span>
              <span className="text-2xl font-black font-mono text-blue-400 block">
                {displayWater}
              </span>
              <span className="text-[11px] text-slate-400 mt-1 block">
                ~62% of functional lean mass
              </span>
            </div>
          </div>

          {/* Segmented Bar */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-slate-300 font-semibold">
                {isUrdu ? 'جسمانی تناسب (Visual Ratio):' : 'Anatomical Tissue Distribution:'}
              </span>
              <div className="flex items-center gap-3 font-mono text-[11px]">
                <span className="text-cyan-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" /> Lean ({100 - results.bodyFatPercentage}%)
                </span>
                <span className="text-rose-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-400" /> Fat ({results.bodyFatPercentage}%)
                </span>
              </div>
            </div>
            <div className="h-4 w-full bg-slate-900 rounded-full overflow-hidden flex border border-slate-800">
              <div style={{ width: `${100 - results.bodyFatPercentage}%` }} className="bg-cyan-500 h-full" />
              <div style={{ width: `${results.bodyFatPercentage}%` }} className="bg-rose-500 h-full" />
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Cardio & Visceral Risk */}
      {activeTab === 'cardio' && (
        <div className="space-y-4">
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <Award className="w-4 h-4" />
              <span>{isUrdu ? 'ڈاکٹر مارگریٹ ایشویل اور UK NICE کلینیکل گائیڈلائن' : 'Dr. Margaret Ashwell & UK NICE Clinical Standard'}</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {isUrdu
                ? 'عالمی تحقیقات ثابت کرتی ہیں کہ صرف وزن یا BMI کے مقابلے میں "ویسٹ ٹو ہائیٹ ریشو" دل کے دورے اور شوگر کی پیشگوئی کرنے میں 87 فیصد زیادہ مؤثر ہے۔ اصول یہ ہے کہ انسان کی کمر کا سائز قد کے نصف (0.50) سے ہمیشہ کم ہونا چاہیے۔'
                : 'Decades of longitudinal medical studies confirm Waist-to-Height Ratio (WHtR) is vastly superior to BMI alone for predicting cardiovascular mortality and Type 2 diabetes. A ratio over 0.50 triggers early microvascular and endothelial stress.'}
            </p>

            {/* Ashwell Scale Table */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
              <div className={`p-3 rounded-xl border text-xs ${
                results.whtr <= 0.49
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}>
                <div className="font-bold mb-0.5">&lt; 0.50 (OK Zone)</div>
                <div className="text-[11px]">{isUrdu ? 'دل اور شریانیں محفوظ ہیں' : 'Low Cardiometabolic Risk'}</div>
              </div>

              <div className={`p-3 rounded-xl border text-xs ${
                results.whtr > 0.49 && results.whtr <= 0.59
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}>
                <div className="font-bold mb-0.5">0.50 - 0.59 (Consider Action)</div>
                <div className="text-[11px]">{isUrdu ? 'معتدل خطرہ، کمر کم کریں' : 'Increased Central Adiposity'}</div>
              </div>

              <div className={`p-3 rounded-xl border text-xs ${
                results.whtr >= 0.60
                  ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}>
                <div className="font-bold mb-0.5">≥ 0.60 (Take Action)</div>
                <div className="text-[11px]">{isUrdu ? 'شدید خطرہ، فوری طبی توجہ' : 'High CVD & Diabetes Risk'}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Calorie & Macro Engine */}
      {activeTab === 'nutrition' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                {isUrdu ? 'بیسل میٹابولک ریٹ (BMR)' : 'Basal Metabolic Rate (BMR)'}
              </span>
              <span className="text-xl font-bold font-mono text-white">
                {results.bmr} <span className="text-xs font-normal text-slate-400">kcal/day</span>
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">
                {isUrdu ? 'بستر پر آرام کے دوران خرچ ہونے والی کیلوریز' : 'Calories burned at pure rest'}
              </span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                {isUrdu ? 'برقراری کیلوریز (TDEE)' : 'Daily Maintenance (TDEE)'}
              </span>
              <span className="text-xl font-bold font-mono text-emerald-400">
                {results.tdee} <span className="text-xs font-normal text-slate-400">kcal/day</span>
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">
                {isUrdu ? 'موجودہ وزن برقرار رکھنے کیلئے' : 'Based on your activity factor'}
              </span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                {isUrdu ? 'چربی کم کرنے کا ہدف (-500 kcal)' : 'Fat Loss Target (-500 kcal)'}
              </span>
              <span className="text-xl font-bold font-mono text-cyan-400">
                {results.calorieTargets.standardLoss} <span className="text-xs font-normal text-slate-400">kcal/day</span>
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">
                ~0.5 kg fat loss / week
              </span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                {isUrdu ? 'لین مسل گین (+250 kcal)' : 'Lean Bulking (+250 kcal)'}
              </span>
              <span className="text-xl font-bold font-mono text-amber-400">
                {results.calorieTargets.leanGain} <span className="text-xs font-normal text-slate-400">kcal/day</span>
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">
                Clean muscular hypertrophy
              </span>
            </div>
          </div>

          {/* Daily Macronutrient Gram Target for Recomposition */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-2 mb-3">
              <Utensils className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                {isUrdu ? 'مسل بچانے اور چربی گھٹانے کیلئے روزانہ میکروز (Grams):' : 'Recomposition Daily Macro Targets (Grams):'}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/30 text-center">
                <span className="text-[10px] text-cyan-400 uppercase tracking-wider block font-bold">
                  Protein
                </span>
                <span className="text-lg font-black font-mono text-white mt-0.5 block">
                  {proteinGrams}g
                </span>
                <span className="text-[10px] text-slate-400">2.0g / kg lean mass</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/30 text-center">
                <span className="text-[10px] text-amber-400 uppercase tracking-wider block font-bold">
                  Fats
                </span>
                <span className="text-lg font-black font-mono text-white mt-0.5 block">
                  {fatGrams}g
                </span>
                <span className="text-[10px] text-slate-400">Hormonal balance</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/30 text-center">
                <span className="text-[10px] text-emerald-400 uppercase tracking-wider block font-bold">
                  Carbs
                </span>
                <span className="text-lg font-black font-mono text-white mt-0.5 block">
                  {carbGrams}g
                </span>
                <span className="text-[10px] text-slate-400">Glycogen energy</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
